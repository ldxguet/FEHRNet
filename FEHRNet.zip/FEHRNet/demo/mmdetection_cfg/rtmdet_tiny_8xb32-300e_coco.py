_base_ = 'mmdet::rtmdet/rtmdet_tiny_8xb32-300e_coco.py'
