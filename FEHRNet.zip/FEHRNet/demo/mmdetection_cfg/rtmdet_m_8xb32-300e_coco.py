_base_ = 'mmdet::rtmdet/rtmdet_m_8xb32-300e_coco.py'
