# Dataflow in MMPose

Coming soon.
